package org.example;

import java.util.HashMap;
import java.util.Map;

/**
 * Represents a university with courses and student enrollments.
 */
 public class University {
    /**
     * A map of courses offered by the university, keyed by course name.
     */
    private final Map<String, Course> courses = new HashMap<>();

    /**
     * Adds a course to the university's list of courses.
     *
     * @param course the course to add
     */
    public void addCourse(final Course course) {
        if (course != null && !courses.containsKey(course.getCourseName())) {
            courses.put(course.getCourseName(), course);
        }
    }

    /**
     * Returns a map of courses offered by the university.
     *
     * @return a map of courses,
     * where the key is the course name and the value is the Course object
     */
    public Map<String, Course> getCourses() {
        return courses;
    }

    /**
     * Registers a student for a course.
     *
     * @param student the student to register
     * @param course  the course to register the student for
     */
    public void registerStudentForCourse(final Student student,
                                         final Course course) {
        if (courses.containsKey(course.getCourseName())) {
            courses.get(course.getCourseName()).addStudent(student);
        }
    }

    /**
     * Prints all course enrollments,
     * showing which students are enrolled in each course.
     */
    public void printEnrollments() {
        for (Course course : courses.values()) {
            System.out.println("Course: " + course.getCourseName());
            for (Student student : course.students) {
                System.out.println("Student: " + student.getName());
            }
        }
    }
}
