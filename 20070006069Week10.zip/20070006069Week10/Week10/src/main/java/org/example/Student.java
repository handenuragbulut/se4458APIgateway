package org.example;

/**
 * Represents a student with a name and ID.
 */
public class Student {
    /**
     * The name of the student.
     */
    private final String studentName;

    /**
     * The ID of the student.
     */
    private String studentID;

    /**
     * Constructs a new student with the given name and ID.
     *
     * @param name the name of the student
     * @param id   the ID of the student
     */
    Student(final String name, final String id) {
        studentName = name;
        studentID = id;
    }

    /**
     * Returns the ID of the student.
     *
     * @return the ID of the student
     */
    public String getStudentID() {
        return studentID;
    }

    /**
     * Returns the name of the student.
     *
     * @return the name of the student
     */
    public String getName() {
        return studentName;
    }
}
