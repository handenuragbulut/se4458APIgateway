package org.example;

/**
 * The main application class that demonstrates the usage
 * of the University,Student, and Course classes.
 */
 public class App {
    /**
     * The maximum capacity for the Software Engineering course.
     */
    static final int SE_CAPACITY = 30;

    /**
     * The maximum capacity for the Data Structures course.
     */
    static final int DS_CAPACITY = 40;
    /**
     * The main method of the application.
     *
     * @param args command line arguments (not used in this application)
     */
     public static void main(final String[] args) {
        University myUniversity = new University();
        Student student1 = new Student("Jane Doe", "001");
        Student student2 = new Student("John Smith", "002");
        Course course1 = new Course("Software Engineering", SE_CAPACITY);
        Course course2 = new Course("Data Structures", DS_CAPACITY);

        myUniversity.addCourse(course1);
        myUniversity.addCourse(course2);
        myUniversity.registerStudentForCourse(student1, course1);
        myUniversity.registerStudentForCourse(student2, course2);

        System.out.println("Total courses offered: "
                + Course.getTotalCourses());
        myUniversity.printEnrollments();
    }
}

