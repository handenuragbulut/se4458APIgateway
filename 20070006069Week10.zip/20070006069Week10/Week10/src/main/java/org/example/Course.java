package org.example;


import java.util.ArrayList;
import java.util.List;

/**
 * Represents a course in a school.
 */
public class Course {
    /**
     * Total number of courses created.
     */
    private static int totalCourses = 0;

    /**
     * The name of the course.
     */
    private final String courseName;

    /**
     * The maximum capacity of students for the course.
     */
    private final int capacity;

    /**
     * The list of students enrolled in the course.
     */
     public final List<Student> students = new ArrayList<>();

    /**
     * Constructs a new course with the given name and capacity.
     *
     * @param name     the name of the course
     * @param capacity the maximum capacity of students for the course
     */
     Course(final String name, final int capacity) {
        courseName = name;
        this.capacity = capacity;
        totalCourses++;
    }

    /**
     * Adds a student to the course if the max capacity has not been reached.
     *
     * @param student the student to add to the course
     */
    public void addStudent(final Student student) {
        if (students.size() < capacity) {
            students.add(student);
        }
    }

    /**
     * Returns the name of the course.
     *
     * @return the name of the course
     */

    public String getCourseName() {
        return courseName;
    }

    /**
     * Returns the total number of courses created.
     *
     * @return the total number of courses created
     */
    public static int getTotalCourses() {
        return totalCourses;
    }
}
